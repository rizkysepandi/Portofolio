#include "water_level_sensor.h"

water_level::water_level(int pin, int maxValue)
  : _pin(pin), _maxValue(maxValue) {
}

bool water_level::init() {
  Serial.println("test water level");
  return true;
}

int water_level::readPercent() {
  return map(readAdc(), 0, _maxValue, 0, 100);
}

int water_level::readAdc() {
  return analogRead(_pin);
}

void water_level::readWaterLevel(setCondition s1, setCondition s2, setCondition s3, setCondition s4) {
  if (readPercent() <= s1._loVal) {
    flag = water_condition::RENDAH;
  } else if (readPercent() > s2._loVal && readPercent() <= s2._hiVal) {
    flag = water_condition::SEDANG;
  } else if (readPercent() > s3._loVal && readPercent() <= s3._hiVal) {
    flag = water_condition::TINGGI;
  } else if (readPercent() >= s4._hiVal) {
    flag = water_condition::BANJIR;
  }
}