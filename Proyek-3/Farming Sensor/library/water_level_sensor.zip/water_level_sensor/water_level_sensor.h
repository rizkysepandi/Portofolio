#pragma once

#include <Arduino.h>

typedef enum
{
  RENDAH,
  SEDANG,
  TINGGI,
  BANJIR
}water_condition;

class setCondition
{
  public:
    int _loVal, _hiVal;
    setCondition(int loVal, int hiVal) : _loVal(loVal), _hiVal(hiVal)
    {

    }
};

class water_level
{
  public :
    water_level(int pin, int maxValue);
    bool init();
    int readPercent();
    void readWaterLevel(setCondition s1, setCondition s2, setCondition s3, setCondition s4);
    water_condition flag;

  private:
    int readAdc();
    int _pin, _maxValue;
};